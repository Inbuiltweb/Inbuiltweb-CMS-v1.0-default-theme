    <!-- Controls the responsiveness of the navbar -->
	<script type="text/javascript">
		(() =>{
			const openNavMenu = document.querySelector(".open-nav-menu"),
			closeNavMenu = document.querySelector(".close-nav-menu"),
			navMenu = document.querySelector(".nav-menu"),
			menuOverlay = document.querySelector(".menu-overlay"),
			mediaSize = 991;

			openNavMenu.addEventListener("click", toggleNav);
			closeNavMenu.addEventListener("click", toggleNav);
			// close the navMenu by clicking outside
			menuOverlay.addEventListener("click", toggleNav);

			function toggleNav() {
				navMenu.classList.toggle("open");
				menuOverlay.classList.toggle("active");
				document.body.classList.toggle("hidden-scrolling");
			}

			navMenu.addEventListener("click", (event) =>{
				if(event.target.hasAttribute("data-toggle") && 
					window.innerWidth <= mediaSize){
					// prevent default anchor click behavior
					event.preventDefault();
					const menuItemHasChildren = event.target.parentElement;
				// if menuItemHasChildren is already expanded, collapse it
				if(menuItemHasChildren.classList.contains("active")){
					collapseSubMenu();
				}
				else{
					// collapse existing expanded menuItemHasChildren
					if(navMenu.querySelector(".menu-item-has-children.active")){
					collapseSubMenu();
					}
					// expand new menuItemHasChildren
					menuItemHasChildren.classList.add("active");
					const subMenu = menuItemHasChildren.querySelector(".sub-menu");
					subMenu.style.maxHeight = subMenu.scrollHeight + "px";
				}
				}
			});
			function collapseSubMenu(){
				navMenu.querySelector(".menu-item-has-children.active .sub-menu")
				.removeAttribute("style");
				navMenu.querySelector(".menu-item-has-children.active")
				.classList.remove("active");
			}
			function resizeFix(){
				// if navMenu is open ,close it
				if(navMenu.classList.contains("open")){
					toggleNav();
				}
				// if menuItemHasChildren is expanded , collapse it
				if(navMenu.querySelector(".menu-item-has-children.active")){
					collapseSubMenu();
				}
			}

			window.addEventListener("resize", function(){
				if(this.innerWidth > mediaSize){
					resizeFix();
				}
			});

		})();
	</script>
	
	<!--JavaScript code to control spinner-->
	<script>
    document.addEventListener("DOMContentLoaded", function() {
    const loader = document.querySelector(".loader-spinner");
    const content = document.querySelector("#content-spinner");

    function showContent() {
        content.style.display = "block";
        loader.style.display = "none";
    }
    
    setTimeout(showContent, 700);
    });
    </script>
    
    <!-- JavaScript code to control announcement -->
    <script>
        const announcement = document.querySelector('.announcement');
        const closeBtn = document.querySelector('#close-btn');
        
        // Check local storage to see if the announcement should be hidden
        const isHidden = localStorage.getItem('announcementHidden');
        if (isHidden) {
          announcement.style.display = 'none';
        }
        
        closeBtn.addEventListener('click', () => {
          // Hide the announcement
          announcement.style.display = 'none';
          
          // Store a flag in local storage to indicate that the announcement is hidden
          localStorage.setItem('announcementHidden', 'true');
          
          // Set a timeout to remove the flag after one day
          setTimeout(() => {
            localStorage.removeItem('announcementHidden');
          }, 24 * 60 * 60 * 1000); // One day in milliseconds
        });
    </script>

    <!-- Load more button -->
    <script>
        let loadMoreBtn = document.querySelector('#load-more');
        let currentItem = 12;

        loadMoreBtn.onclick = () =>{
            let boxes = [...document.querySelectorAll('.bg-container .latest-container .contents')];
            for (var i = currentItem; i < currentItem + 6; i++){
                boxes[i].style.display = 'inline-block';
            }
            currentItem += 6;

            if(currentItem >= boxes.length){
                loadMoreBtn.style.display = 'none';
            }
        }
    </script>

    <!-- Get to the top function -->
    <script>
        //Get the button
        var mybutton = document.getElementById("to-top");

        // When the user scrolls down 50px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
        if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        }
    </script>

    <!-- Customer review card -->
    <script>
      var reviewslide = document.getElementById("review-slide");
      var upArrow = document.getElementById("upArrow");
      var downArrow = document.getElementById("downArrow");

      let x = 0;

      upArrow.onclick = function(){
        if(x > "-900"){
          x = x - 300;
          reviewslide.style.top = x + "px";
        }
      }

      downArrow.onclick = function(){
        if(x < 0){
          x = x + 300;
          reviewslide.style.top = x + "px";
        }
      }
    </script>

	<!-- Top navigation bar -->
	<style type="text/css">
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
    }

    body{
        background-color: #e0dddd;
        width: 100%;
        height: auto;
    }
    
    /* Style the load spinner */
    .loader-spinner {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        background-color: #e0dddd;
    }

    .loading-spinner {
        border: 6px solid transparent;
        border-top: 6px solid <?php echo $result_siteinfo["primary_color"]; ?>;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        animation: spin 1s linear infinite;
    }

    /* Define the animation */
    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }

    /*announcement*/
    .announcement {
      position: relative;
      background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
      color: <?php echo $result_siteinfo["primary_color"]; ?>;
      padding: 10px;
      text-align: center;
      align-items: center;
      align-content: center;
    }
    
    #close-btn {
      color: #ffffff;
      background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
      cursor: pointer;
      margin-left: 10px;
    }
    
    #close-btn:hover {
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }


    /*header*/
    .navbar{
        position: sticky;
        width: 100%;
        top:0;
        z-index: 1000;
    }
    .navbar-main{
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 0;
    }
    .navbar-main a{
        text-decoration: none;
    }
    .navbar .logo{
        padding: 0 15px;
    }
    .navbar .logo a{
        font-size: 30px;
        text-transform: capitalize;
        color: #ffffff;
        text-decoration: none;
        font-weight: 600;
    }
    .navbar .nav-menu{
        padding: 0 15px;
    }
    .navbar .menu > .menu-item{
        display: inline-block;
        margin-left: 30px;
        position: relative;
    }
    .navbar .menu > .menu-item > a{
        display: block;
        padding: 12px 0;
        font-size: 16px;
        color: #ffffff;
        text-transform: capitalize;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    .navbar .menu > .menu-item > a .plus{
        display: inline-block;
        height: 12px;
        width: 12px;
        position: relative;
        margin-left:5px; 
        pointer-events: none;
    }
    .navbar .menu > .menu-item > a .plus:before,
    .navbar .menu > .menu-item > a .plus:after{
        content:'';
        position: absolute;
        box-sizing: border-box;
        left: 50%;
        top:50%;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        height: 2px;
        width: 100%;
        transform: translate(-50%,-50%);
        transition: all 0.3s ease;
    }
    .navbar .menu > .menu-item:hover > a .plus:before,
    .navbar .menu > .menu-item:hover > a .plus:after{
    background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }
    .navbar .menu > .menu-item > a .plus:after{
    transform: translate(-50%,-50%) rotate(-90deg);	
    }
    .navbar .menu > .menu-item > .sub-menu > .menu-item > a:hover,
    .navbar .menu > .menu-item:hover > a{
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }
    .navbar .menu > .menu-item > .sub-menu{
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
        width: 220px;
        position: absolute;
        left:0;
        top:100%;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        padding: 10px 0;
        border-top: 3px solid <?php echo $result_siteinfo["secondary_color"]; ?>;
        transform: translateY(10px);
        transition: all 0.3s ease;
        opacity:0;
        visibility: hidden;
    }
    @media only screen and (min-width: 970px){
        .navbar .menu > .menu-item-has-children:hover > .sub-menu{
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }
        .navbar .menu > .menu-item-has-children:hover > a .plus:after{
            transform: translate(-50%,-50%) rotate(0deg);		
        }
    }
    .navbar .menu > .menu-item > .sub-menu > .menu-item{
        display: block;
    }
    .navbar .menu > .menu-item > .sub-menu > .menu-item > a{
        display: block;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: 600;
        color: #ffffff;
        transition: all 0.3s ease;
        text-transform: capitalize;
    }
    .navbar .open-nav-menu{
        height: 34px;
        width: 40px;
        margin-right: 15px;
        display: none;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }
    .navbar .open-nav-menu span{
        display: block;
        height: 3px;
        width: 24px;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        position: relative;
    }
    .navbar .open-nav-menu span:before,
    .navbar .open-nav-menu span:after{
        content: '';
        position: absolute;
        left:0;
        width: 100%;
        height: 100%;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        box-sizing: border-box;
    }
    .navbar .open-nav-menu span:before{
        top:-7px;
    }
    .navbar .open-nav-menu span:after{
        top:7px;
    }
    .navbar .close-nav-menu{
        height: 40px;
        width: 40px;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        margin:0 0 15px 15px;
        cursor: pointer;
        display: none;
        align-items: center;
        justify-content: center;
    }
    .navbar .close-nav-menu span{
        width: 16px;
    }
    .navbar .menu-overlay{
        position: fixed;
        z-index: 999;
        left:0;
        top:0;
        height: 100%;
        width: 100%;
        visibility: hidden;
        opacity:0;
        transition: all 0.3s ease;
    }

    .navbar .menu-item form button {
        background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }


    /* responsive */

    @media only screen and (max-width: 970px){
        .navbar .menu-overlay.active{
        visibility: visible;
        opacity: 1;
        }
        .navbar .nav-menu{
            position: fixed;
            right: -280px;
            visibility: hidden;
            width: 280px;
            height: 100%;
            top:0;
            overflow-y: auto;
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            z-index: 1000;
            padding: 15px 0;
            transition: all 0.5s ease;
        }
        .navbar .nav-menu.open{
            visibility: visible;
            right: 0px;
            color: #ffffff;
        }
        .navbar .menu > .menu-item{
            display: block;
            margin:0;
        }
        .navbar .menu > .menu-item-has-children > a{
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar .menu > .menu-item > a{
            color: #ffffff;
            padding: 12px 15px;
            border-bottom: 1px solid <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        .navbar .menu > .menu-item:first-child > a{
            border-top: 1px solid <?php echo $result_siteinfo["secondary_color"]; ?>;	
        }
        .navbar .menu > .menu-item > a .plus:before, 
        .navbar .menu > .menu-item > a .plus:after{
            background-color: #ffffff;
        }
        .navbar .menu > .menu-item-has-children.active > a .plus:after{
            transform: translate(-50%,-50%) rotate(0deg);
        }
        .navbar .menu > .menu-item > .sub-menu{
            width: 100%;
            position: relative;
            opacity: 1;
            visibility: visible;
            border:none;
            background-color: transparent;
            box-shadow: none;
            transform: translateY(0px);
            padding: 0px;
            left: auto;
            top:auto;
            max-height: 0;
            overflow: hidden;
        }
        .navbar .menu > .menu-item > .sub-menu > .menu-item > a{
            padding: 12px 45px;
            color: #ffffff;
            border-bottom: 1px solid <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        .navbar .close-nav-menu,
        .navbar .open-nav-menu{
            display: flex;
            color: #ffffff;
        }

        .navbar .menu-item form {
            margin: 10px;
        }
    }
	</style>

	<!-- Side navigation bar -->
	<style type="text/css">
    .main-menu .fa-2x {
    font-size: 2em;
    }
    
    .main-menu .fa {
    position: relative;
    display: table-cell;
    width: 60px;
    height: 36px;
    text-align: center;
    vertical-align: middle;
    font-size:20px;
    }


    .main-menu:hover,nav.main-menu.expanded {
    width:250px;
    overflow:visible;
    }

    .main-menu {
    background:<?php echo $result_siteinfo["primary_color"]; ?>;
    border-right:1px solid <?php echo $result_siteinfo["secondary_color"]; ?>;
    position:fixed;
    top:75px;
    bottom:0;
    height:100%;
    left:0;
    width:60px;
    overflow:hidden;
    transition: .05s linear;
    z-index:1000;
    }

    .main-menu>ul {
    margin:7px 0;
    }

    .main-menu li {
    position:relative;
    display:block;
    width:250px;
    }

    .main-menu li>a {
    position:relative;
    display:table;
    border-collapse:collapse;
    border-spacing:0;
    color:#ffffff;
    font-family: arial;
    font-size: 14px;
    text-decoration:none;
    transition:all .1s linear;
    
    }

    .main-menu .nav-icon {
    position:relative;
    display:table-cell;
    width:60px;
    height:36px;
    text-align:center;
    vertical-align:middle;
    font-size:18px;
    }

    .main-menu .nav-text {
    position:relative;
    display:table-cell;
    vertical-align:middle;
    width:190px;
    }

    .no-touch .scrollable.hover {
    overflow-y:hidden;
    }

    .no-touch .scrollable.hover:hover {
    overflow-y:auto;
    overflow:visible;
    }

    a:hover,a:focus {
    text-decoration:none;
    }

    nav ul,nav li {
    outline:0;
    margin:0;
    padding:0;
    }
    .main-menu li:hover>a,nav.main-menu li.active>a,.dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus,.dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus,.no-touch .dashboard-page nav.dashboard-menu ul li:hover a,.dashboard-page nav.dashboard-menu ul li.active a {
    color:#ffffff;
    background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }
    
    @media only screen and (max-width: 970px){
        .main-menu .fa-2x {
            font-size: 1em;
        }
        
        .main-menu {
            width:30px;
        }
        
        .main-menu .fa {
            width: 30px;
        }
    }

	</style>

    <!-- Homepage -->
    <style>
        .heading{
            text-align: center;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
            display: inline-block;
            position: relative;
            margin-bottom: 20px;
        }

        .heading::before, .heading::after{
        content: '';
        position: absolute;
        height: 10px;
        width: 15px;
        border-top: 5px solid <?php echo $result_siteinfo["primary_color"]; ?>;
        border-left: 5px solid <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .heading::before{
        top: -5px; 
        left: -10px;
        }

        .heading::after{
        bottom: -5px; 
        right: -10px;
        transform: rotate(180deg);
        }

        .homepage{
        height: 80vh;
        width: 100%;
        background: linear-gradient(<?php echo $result_siteinfo["primary_color"]; ?>, <?php echo $result_siteinfo["secondary_color"]; ?>);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-flow: column;
        text-align: center;
        position: relative;
        overflow: hidden !important;
        overflow-x: hidden !important;
        }

        .homepage .banner-homepage{
        color: #ffffff;
        font-size: 40px;
        text-shadow: 5px 10px 15px <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .homepage .slogan-homepage{
        color: #fff;
        font-size: 20px;
        font-weight: 400;
        }

        .homepage button{
        height: 30px;
        width: 130px;
        padding: 5px;
        background: #fff;
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
        cursor: pointer;
        border: none;
        outline: none;
        margin-top: 5px;
        font-size: 20px;
        font-weight: 400;
        }

        .homepage button:hover{
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .homepage .wave{
        position: absolute;
        bottom: -20px;
        left: 0;
        height: 100px;
        width: 100%;
        background: url(assets/wave.png);
        background-size: 600px 100px;
        background-repeat: repeat-x;
        animation: waves 10s linear infinite;
        overflow: hidden;
        }

        .homepage .wave2{
        animation-direction: reverse;
        opacity: .2;
        }

        .homepage .wave3{
        animation-duration: 4s;
        opacity: .5;
        }

        @keyframes waves{
        0%{
            background-position-x: 0;
        }
        100%{
            background-position-x: 500px;
        }
        }

        .homepage .fa-cog{
        position: absolute;
        font-size: 400px;
        opacity: .15;
        color: #fff;
        animation: rotate 10s linear infinite;
        }
        
        @media only screen and (max-width: 970px){
            .homepage .banner-homepage{
            font-size: 30px;
            }
            
            .homepage .slogan-homepage{
            font-size: 15px;
            }
            
            .homepage .fa-cog{
            font-size: 300px;
            }
        }

        .homepage .nut1{
        top:10%; 
        left: -135px;
        }

        .homepage .nut2{
        bottom:23%; 
        right: -145px;
        animation-direction: reverse;
        }

        @keyframes rotate{
        100%{
            transform: rotate(360deg);
            }
        }

        /*background detail*/
        .containerbox{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            background-color: #ffffff;
        }

        .containerbox .setting{
            position: relative;
            width: 300px;
            margin: 20px;
            box-sizing: border-box;
            overflow: hidden;
            text-align: center;
        }

        .containerbox .setting .display i{
            font-size: 50px;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
            width: 70px;
            height: 40px;
            margin-top: 2px;
            margin-bottom: 10px;
            margin-left: 5px;
            margin-right: 5px;
        }

        .containerbox .setting .display{
            display: flex;
            position: relative;
            width: 80px;
            height: 80px;
            align-items: center;
            margin: 0 auto;
        }

        .containerbox .setting .content{
            position: relative;
            z-index: 1;
            transition: 0.5s;
            color: #ffffff;
        }

        .containerbox .setting .content h3{
            font-size: 20px;
            margin: 10px 0;
            padding: 0;
            color: #000000;
        }

        .containerbox .setting .content p{
            margin: 0;
            padding: 0;
            color: #000000;
        }

        .services{
            background-color: #ffffff;
            display: block;
            text-align: center;
        }

        .services-starts{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            background-color: #ffffff;
        }

        .service-section{
            position: relative;
            width: 300px;
            height: auto;
            margin: 20px;
            box-shadow: 0 2px 7px <?php echo $result_siteinfo["primary_color"]; ?>;
            border-radius: 4px;
            box-sizing: border-box;
            overflow: hidden;
            text-align: center;
        }

        .service-section:hover{
            background-color: #e0dddd;
        }

        .service-section img{
            height: 150px;
            width: 250px;
        }

        .service-section p{
            margin: 10px;
        }

        .service-section button{
            margin: 10px;
            padding: 5px;
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            border-radius: 5px;
        }

        .service-section button a:hover{
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .service-section button a{
            color: #ffffff;
            text-decoration: none;
        }

        /* customer review */
        .review-hero{
          width: 100%;
          height: 350px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: linear-gradient(<?php echo $result_siteinfo["secondary_color"]; ?>, transparent 100%);
        }

        .review-box{
          width: 70%;
          height: 250px;
          border-radius: 10px;
          box-shadow: -5px 5px 20px <?php echo $result_siteinfo["primary_color"]; ?>;
          position: relative;
          overflow: hidden;
        }

        .review-card{
          height: 300px;
          padding: 25px;
          box-sizing: border-box;
          background-color: #ffffff;
          position: relative;
          z-index: 1;
        }

        .review-card::before{
          content: '';
          width: 110px;
          height: 110px;
          border-bottom-right-radius: 100%;
          background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
          position: absolute;
          top: 0;
          left: 0;
          z-index: -1;
        }

        .review-profile{
          display: flex;
          align-items: center;
          margin-bottom: 10px;
        }

        .review-profile img{
          width: 80px;
          height: 80px;
          border-radius: 50%;
          margin-right: 20px;
        }

        .review-profile h4{
          color: <?php echo $result_siteinfo["primary_color"]; ?>;
          margin-bottom: 5px;
        }

        .review-profile h5{
          color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        #review-slide{
          width: 100%;
          padding-right: 60px;
          box-sizing: border-box;
          position: absolute;
          top: 0;
          left: 0;
          transition: 0.5s;
        }

        .review-slidebar{
          width: 60px;
          height: 100%;
          padding: 15px 0;
          box-sizing: border-box;
          background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
          position: absolute;
          right: 0;
          top: 0;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          align-items: center;
        }

        .review-slidebar i{
          width: 30px;
          padding: 5px;
          color: <?php echo $result_siteinfo["secondary_color"]; ?>;
          background-color: #ffffff;
          height: 30px;
          border-radius: 70%;
          cursor: pointer;
          text-align: center;
        }

        @media only screen and (max-width: 970px){
            .review-box{
            width: 95%;
            }

            .review-profile img{
            width: 70px;
            height: 70px;
            }
        }
        
        .blog-title {
            text-align: center;
            margin-top: 20px;
        }

        /* Executive team */
        .our-team{
            background-color: #ffffff;
            text-align: center;
        }

        .our-team h2{
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
            margin-top: 10px;
            margin-bottom: 60px;
            text-align: center;
        }

        .team{
            display: flex;
            text-align: center;
            width: auto;
            justify-content: center;
            flex-wrap: wrap;
        }

        .team .team-member{
            background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            margin: 5px;
            margin-bottom: 50px;
            width: 300px;
            padding: 20px;
            line-height: 20px;
            position: relative;
        }

        .team .team-member h3{
            margin-top: 50px;
        }

        .team .team-member p.role{
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
            margin: 12px 0;
        }

        .team .team-member .team-image{
            width: 100px;
            height: 100px;
            border-radius: 50%;
            position: absolute;
            top: -50px;
            left: 50%;
            transform: translateX(-50%);
            background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .team .team-member .team-image img{
            width: 100px;
            height: 100px;
            padding: 10px;
            border-radius: 50%;
        }

        /* Frequently asked question */
        .frequently-asked{
            background-image: url(/assets/Inbuiltweb_bot_success.webp);
            background-size: 500px;
            background-repeat: no-repeat;
            background-position: center;
            background-color: #ffffff;
            display: block;
            position: relative;
            text-align: center;
        }

        .accordion-body{
        z-index: 5;
        display: flex;
        align-items: center;
        justify-content: center;
        height: auto;
        margin-top: 10px;
        margin-bottom: 10px;
        }
        /*::selection{
        background-color: #ffffff;
        }*/
        .accordion-wrap{
        width: 100%;
        padding: 0 20px;
        }
        .accordion-wrap .parent-accordion,
        .accordion-wrap .child-accordion{
        margin-bottom: 8px;
        border-radius: 3px;
        }
        .accordion-wrap .parent-accordion label,
        .accordion-wrap .child-accordion label{
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        cursor: pointer;
        border-radius: 3px;
        position: relative;
        transition: all 0.3s ease;
        }
        /*.accordion-wrap .parent-accordion label:hover{
        background-color: #e0dddd;
        }*/
        .parent-accordion input:checked ~ label,
        .child-accordion input:checked ~ label{
        border-radius: 3px 3px 0 0;
        }
        .accordion-wrap label span{
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
        font-size: 18px;
        font-weight: 300;
        }
        .accordion-wrap .child-accordion label span{
        font-size: 17px;
        }
        .parent-accordion label .object{
        position: relative;
        height: 30px;
        width: 30px;
        font-size: 15px;
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
        display: block;
        background: #ffffff;
        border-radius: 50%;
        }
        .accordion-wrap .child-accordion label .object{
        height: 27px;
        width: 27px;
        }
        .parent-accordion label .object i{
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        }
        .parent-accordion input:checked ~ label .object i:before,
        .child-accordion input:checked ~ label .object i:before{
        content: '\f068';
        }
        .accordion-wrap .parent-accordion .accordion-text,
        .accordion-wrap .child-accordion .sub-accordion-text{
        max-height: 0px;
        overflow: hidden;
        border-radius: 0 0 3px 3px;
        transition: all 0.4s ease;
        text-align: left;
        }
        .parent-accordion input:checked ~ .accordion-text,
        .child-accordion input:checked ~ .sub-accordion-text{
        max-height: 100vh;
        }
        .accordion-3 input:checked ~ .accordion-text{
        padding: 15px 20px;
        }
        .parent-accordion .accordion-text p,
        .child-accordion .sub-accordion-text p{
        padding: 15px 20px;
        font-size: 16px;
        }
        .child-accordion .sub-accordion-text p{
        font-size: 15px;
        }
        input[type="radio"],
        input[type="checkbox"]{
        display: none;
        }
    </style>

	<!-- Body -->
	<style type="text/css">

    /* Carousel */
    .slider-wrapper {
    position: relative;
    overflow: hidden;
    }

    .slides-container {
    height: 450px;
    width: 100%;
    display: flex;
    overflow: scroll;
    overflow-y:hidden;
    scroll-behavior: smooth;
    list-style: none;
    margin: 0;
    padding: 0;
    }

    .slide-arrow {
    position: absolute;
    display: flex;
    top: 0;
    bottom: 0;
    margin: auto;
    height: 4rem;
    border: none;
    width: 2rem;
    font-size: 3rem;
    padding: 0;
    cursor: pointer;
    opacity: 0.5;
    transition: opacity 100ms;
    }

    .slide-arrow i {
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }

    .slide-arrow:hover,
    .slide-arrow:focus {
    opacity: 1;
    }

    #slide-arrow-prev {
    left: 0;
    padding-left: 0.25rem;
    border-radius: 0 2rem 2rem 0;
    }

    #slide-arrow-next {
    right: 0;
    padding-left: 0.75rem;
    border-radius: 2rem 0 0 2rem;
    }

    .slide {
    width: 100%;
    height: 100%;
    flex: 1 0 100%;
    text-align: center;
    border-radius: 5px;
    }

    .featured-contents{
        background-color: #e0dddd;
        margin: 20px;
        border-radius: 5px;
    }

    .slide button {
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        text-align: center;
        border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        border-radius: 5px;
        margin: 5px;
        padding: 5px;
    }

    .slide button:hover{
        border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }

    .slide a{
        text-decoration: none;
        color: #ffffff;
        margin: 5px;
    }

    .slide a:hover{
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }

    .slide i {
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }

    @media only screen and (max-width: 970px) {
        .slides-container {
        height: 400px;
        }
    }
    /* Body contents */
    .bg-container{
        background-color: #ffffff;
        margin: 20px;
        justify-content: center;
        align-items: center;
    }
    
    .bg-container .heading {
        text-align: center;
    }

    .bg-container #item-title-box {
        margin: 5px;
        text-align: center;
    }
    
    .bg-container #item-description-box {
        margin: 5px;
    }
    
    .to-all-clients{
    text-align: center;
    justify-content: center;
    align-items: center;
    }
    
    .message-all {
    position: relative;
    display: inline-block;
    color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }

    .message-all .message-all-form {
    visibility: hidden;
    width: 200px;
    background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
    color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    
    /* Position the form */
    position: absolute;
    z-index: 7;
    top: -5px;
    left: 100%;
    }

    .message-all .message-all-form button {
        color: #ffffff;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        padding: 5px;
        border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }

    .message-all .message-all-form a {
        color: #ffffff;
    }

    .message-all .message-all-form button:hover {
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }

    .message-all .message-all-form a:hover {
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }

    .message-all:hover .message-all-form {
    visibility: visible;
    }

    .bg-container h6{
        margin: 5px;
        text-align: center;
    }

    .bg-container h3 a {
        text-decoration: none;
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }

    .bg-container h3 a:hover {
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }

    .bg-container #myInput {
        display: block;
        margin-left: auto;
        margin-right: auto;
        padding: 5px;
        margin-bottom: 5px;
        border: 1px solid #e0dddd;
        border-radius: 4px;
    }

    .latest-container{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
    }

    .contents{
        position: relative;
        width: 300px;
        justify-content: center;
        align-items: center;
        text-align: center;
        box-shadow: 0 2px 7px <?php echo $result_siteinfo["primary_color"]; ?>;
        border-radius: 4px;
        margin: 20px;
        box-sizing: border-box;
        overflow: hidden;
    }

    .contents i{
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }

    .contents img{
        height: 150px;
        width: 300px;
        border-radius: 5px;
    }

    .contents video{
        height: 150px;
        width: 300px;
        border-radius: 5px;
    }

    .contents button{
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        text-align: center;
        border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        border-radius: 5px;
        margin: 5px;
        padding: 5px;
    }

    .contents button:hover{
        border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
    }

    .contents a{
        text-decoration: none;
        color: #ffffff;
        margin: 5px;
    }

    .contents a:hover{
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }
    
    #all-more {
        justify-content: center;
        text-align: center;
    }

    #all-more button {
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        text-align: center;
        border-radius: 5px;
        border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        margin-bottom: 2px;
        padding: 5px;
    }
    
    #all-more button a {
        text-decoration: none;
        color: #ffffff;
    }

    #all-more button a:hover {
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }

    /* Load more feature */
    .bg-container .latest-container .contents {
        display: none;
    }

    .bg-container .latest-container .contents:nth-child(1),
    .bg-container .latest-container .contents:nth-child(2),
    .bg-container .latest-container .contents:nth-child(3),
    .bg-container .latest-container .contents:nth-child(4),
    .bg-container .latest-container .contents:nth-child(5),
    .bg-container .latest-container .contents:nth-child(6){
        display: inline-block;
    }

    #load-more {
        justify-content: center;
        text-align: center;
    }

    #load-more button {
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        text-align: center;
        border-radius: 5px;
        border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        margin-bottom: 2px;
        color: #ffffff;
        padding: 5px;
    }

    #load-more button:hover {
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    }
	</style>

	<!-- Footer -->
	<style type="text/css">
    /*FOOTER*/
	.footer-section{
		background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
		z-index: 500;
	}

	.footer-section .main-content{
		display: flex;
		width: 100%;
		background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
		border-radius: 4px;
	}

	.footer-section .main-content a{
		text-decoration: none;
		color: #ffffff;
	}

	.footer-section .main-content a:hover{
		color: <?php echo $result_siteinfo["secondary_color"]; ?>;
	}

	.footer-section .main-content .box{
		flex-basis: 50%;
		padding: 10px 20px;
	}

	.footer-section .box h2{
		font-size: 1.125rem;
		font-weight: 600;
		text-transform: uppercase;
		color: <?php echo $result_siteinfo["secondary_color"]; ?>;
	}

	.footer-section .box .content{
		margin: 20px 0 0 0;
		position: relative;
	}

	.footer-section .box .content:before{
		position: absolute;
		content: '';
		top: -10px;
		height: 2px;
		width: 100%;
		background-color: #ffffff;
	}

	.footer-section .box .content:after{
		position: absolute;
		content: '';
		height: 2px;
		width: 15%;
		background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
		top: -10px;
	}

	.footer-section .left .content p{
		color: #ffffff;
	}

	.footer-section .left .content .social{
		margin: 22px 0 0 0;
	}

	.footer-section .left .content .social a{
		padding: 0 2px;
		text-decoration: none;
	}
	
	.footer-section .left .content .social a{
		height: 40px;
		width: 40px;
		line-height: 40px;
		text-align: center;
		font-size: 18px;
		border-radius: 5px;
		transition: 0.3s;
	}
	
	.footer-section .left .content .social a:hover{
		color: <?php echo $result_siteinfo["secondary_color"]; ?>;
	}
	
	.footer-section .center .content .fa{
		height: 35px;
		width: 40px;
		line-height: 20px;
		text-align: center;
		cursor: pointer;
	}

	.footer-section .right .content p{
		margin-bottom: 4px;
	}
	
	@media only screen and (max-width: 970px) {
		.footer-section{
		position: relative;
		bottom: 0px;
		}

		.main-content{
		flex-wrap: wrap;
		flex-direction: column;
		}

		.main-content .box{
		margin: 5px 0;
		}
	}

    .app-and-translate {
        display: grid;
        grid-template-columns: auto auto;
        justify-content: center;
        align-items: center;
        color: #ffffff;
        margin-bottom: 10px;
    }

    .app-and-translate i {
        margin-right: 5px;
        font-size: 30px;
    }

    .app-and-translate select {
        margin-left: 5px;
    }

    #application-display img {
        height: 35px;
        width: 100px;
        margin: 5px;
    }

    #to-top {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 30px;
    z-index: 1000;
    border: none;
    outline: none;
    background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
    color: <?php echo $result_siteinfo["secondary_color"]; ?>;
    cursor: pointer;
    padding: 15px;
    border-radius: 4px;
    }

	.copyright_and_others{
		top: 0;
		width: 100%;
		text-align: center;
		color: #e0dddd;
	}

	.copyright_and_others a{
		text-decoration: none;
	}

	@media only screen and (max-width: 970px) {
		.copyright_and_others{
			padding: 8px 40px;
		}
	}
	</style>

    <!-- Dashboard -->
    <style type="text/css">
        .bg-container .setup {
            text-align: center;
            margin: 5px;
        }

        .bg-container .setup a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .bg-container .setup a:hover{
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .traffic-card {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        }

        .t-card{
        position: relative;
        width: 320px;
        height: 70px;
        justify-content: center;
        align-items: center;
        text-align: center;
        box-shadow: 0 2px 7px <?php echo $result_siteinfo["primary_color"]; ?>;
        border-radius: 4px;
        margin: 20px;
        box-sizing: border-box;
        overflow: hidden;
        }

        .t-card p {
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
            margin: 10px;
        }

        .t-card button {
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        text-align: center;
        border-radius: 5px;
        border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        margin-bottom: 2px;
        padding: 5px;
        }

        .t-card button a {
         color: #ffffff;
         text-decoration: none;
        }

        .t-card button a:hover{
         color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .traffic-card strong {
            box-shadow: 2px 2px 2px <?php echo $result_siteinfo["secondary_color"]; ?>;
            margin: 5px;
        }
        
        .version {
            display: block;
        }
        
        .version h6 {
            text-align: right;
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            margin-right: 20px;
        }
    </style>

    <!-- Display contents -->
    <style type="text/css">
        .container-content {
            margin: 20px;
        }

        .container-content p, h1, h2, h3, h4, h5, h6 {
            margin-bottom: 10px;
        }

        .container-content a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .container-content a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .container-content a i {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .container-content a i:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .content-info strong {
            margin: 5px;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .content-info a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .content-info a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        
        .container-content .advertisements {
            display: block;
            overflow: hidden;
        }

        .container-content form {
            margin-top: 10px;
        }

        .container-content .related-contents {
            display: flex;
            flex-wrap: wrap;
        }

        .container-content .related-content {
            width: 200px;
            box-shadow: 0 2px 7px <?php echo $result_siteinfo["primary_color"]; ?>;
            border-radius: 4px;
            margin: 10px;
            box-sizing: border-box;
            overflow: hidden;
            text-align: center;
        }

        .container-content .related-content img {
            height: 100px;
            width: 200px;
            border-radius: 5px;
        }

        .container-content .related-content video {
            height: 100px;
            width: 200px;
            border-radius: 5px;
        }

        .container-content .related-content a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .container-content .related-content a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .container-content form label {
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .container-content form button {
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            color: #ffffff;
            padding: 5px;
        }

        .container-content form button:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        
        .container-content .search-terms {
            display: flex;
            flex-wrap: wrap;
        }
        
        .container-content .search-terms button {
            margin: 2px;
        }

        .comments-section a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .comments-section a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .comments-section {
            margin-bottom: 10px;
        }

        .comments-section button {
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            text-align: center;
            border-radius: 5px;
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            margin-bottom: 2px;
            color: #ffffff;
            padding: 5px;
        }

        .comments-section button:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .comment-approved {
            margin-top: 10px;
        }

        .comment-approved h6 {
            text-align: left;
        }

        .comment-approved #comment-user {
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .comment-approved #user-message {
            margin-bottom: 10px;
        }

        .comment-response {
        position: relative;
        display: inline-block;
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .comment-response .response-form {
        visibility: hidden;
        width: 200px;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0;
        
        /* Position the form */
        position: absolute;
        z-index: 7;
        top: -5px;
        left: 100%;
        }

        .comment-response .response-form button {
            color: #ffffff;
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            padding: 5px;
        }

        .comment-response .response-form a {
            color: #ffffff;
        }

        .comment-response .response-form button:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .comment-response .response-form a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .comment-response:hover .response-form {
        visibility: visible;
        }

        #get_comment_id {
            display: none;
        }

        .comment-approved #comment-user-response {
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
            margin-left: 20px;
        }

        .comment-approved #user-message-response {
            margin-bottom: 10px;
            margin-left: 20px;
        }

        .container-content img {
            height: 450px;
            width: 100%;
            border-radius: 5px;
            margin-bottom: 5px;
        }

        .container-content video {
            height: 450px;
            width: 100%;
            border-radius: 5px;
            margin-bottom: 5px;
        }

        @media only screen and (max-width: 970px) {
            .container-content img {
            height: 200px;
            }

            .container-content iframe {
            height: 200px;
            }
        }

        .bg-container .selected-records {
            display: block;
            text-align: center;
            justify-content: center;
            align-items: center;
        }

        .bg-container .selected-records button {
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            padding: 5px;
        }

        .bg-container .selected-records button:hover {
            border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .bg-container .selected-records a {
            color: #ffffff;
            text-decoration: none;
        }

        .bg-container .selected-records a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .bg-container .container-paynow {
            margin-left: 20px;
            height: 300px;
        }

        .bg-container .container-paynow h4, h5 {
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .bg-container .container-paynow button {
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            color: #ffffff;
            padding: 5px;
        }

        .bg-container .container-paynow button:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .bg-container .container-paynow a {
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
            text-decoration: none;
        }

        .bg-container .container-paynow a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .bg-container .container-paynow h5 {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        
        .bg-container .container-success {
            margin-left: 20px;
            height: 300px;
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            background-image: url(https://www.inbuiltweb.com/assets/Inbuiltweb_bot_success.webp);
            background-size: 250px;
            background-repeat: no-repeat;
            background-position: center;
        }

        .bg-container .container-error {
            margin-left: 20px;
            height: 300px;
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            background-image: url(https://www.inbuiltweb.com/assets/Inbuiltweb_bot_error.webp);
            background-size: 250px;
            background-repeat: no-repeat;
            background-position: center;
        }
    </style>

    <!-- Contents & tables-->
    <style type="text/css">
        .contents-table {
        height: 400px;
        width: 100%;
        display: flex;
        overflow: scroll;
        scroll-behavior: smooth;
        list-style: none;
        margin: 0;
        padding: 0;
        }

        #table-traffic {
        justify-content: center;
        align-items: center;
        text-align: center;
        }

        #table-record {
        border-collapse: collapse;
        width: 90%;
        justify-content: center;
        align-items: center;
        text-align: center;
        margin-left: auto;
        margin-right: auto;
        }

        #table-record td, #table-record th {
        border: 1px solid #e0dddd;
        padding: 8px;
        }

        #table-record tr:nth-child(even){background-color: ;}

        #table-record tr:hover {background-color: #e0dddd;}

        #table-record th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        color: white;
        }

        #table-record a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        #table-record a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        #table-record button {
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            color: #ffffff;
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            padding: 5px;
        }
        
        #table-record button a {
            color: #ffffff;
        }

        #table-record button:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        #table-record video {
            width: 50px; 
            height: 40px;
        }
        
        /* For larger tables */
        @media only screen and (min-width: 970px) {
            #table-record-large {
                display: block;
            }
        }
        
        #table-record-large {
        border-collapse: collapse;
        width: 90%;
        justify-content: center;
        align-items: center;
        text-align: center;
        margin-left: auto;
        margin-right: auto;
        }

        #table-record-large td, #table-record-large th {
        border: 1px solid #e0dddd;
        padding: 8px;
        }

        #table-record-large tr:nth-child(even){background-color: ;}

        #table-record-large tr:hover {background-color: #e0dddd;}

        #table-record-large th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        color: white;
        }

        #table-record-large a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        #table-record-large a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        #table-record-large button {
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            color: #ffffff;
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            padding: 5px;
        }

        #table-record-large button:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        #table-record-large video {
            width: 50px; 
            height: 40px;
        }
    </style>

    <!-- contents & forms -->
    <style type="text/css">
        .container-form {
        padding: 20px;
        height: 520px;
        width: 100%;
        display: flex;
        overflow: scroll;
        scroll-behavior: smooth;
        list-style: none;
        margin: 0;
        }
        
        .container-form form {
            margin-left: auto;
            margin-right: auto;
            justify-content: center;
            align-items: center;
        }
        
        .container-form input[type=text], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form input[type=email], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form input[type=number], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form input[type=tel], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form input[type=file], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form input[type=password], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form input[type=checkbox] {
            display: block;
            margin-bottom: 2px;
            margin-top: 2px;
        }
        
        .container-form video {
            width: 55px; 
            height: 45px;
        }
        
        .container-form #logo {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        
        .container-form #header-codes {
            width: 250px;
        }
        
        .container-form #advert-form {
            width: 200px;
        }

        .container-form button {
         color: #ffffff;
         text-decoration: none;
         background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
         border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
         margin-bottom: 5px;
         padding: 5px;
        }

        .container-form #reset-button {
            margin-left: 5px;
            margin-bottom: 5px;
        }

        .container-form button:hover{
         color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .container-form a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .container-form a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        
        @media only screen and (min-width: 970px) {
            .container-form form {
                max-width: 70%;
            }
            
            .container-form #register-form {
                max-width: 50%;
            }
            
            .container-form #header-codes {
                width: 500px;
            }
            
            .container-form #advert-form {
                width: 300px;
            }
        }
        
        .container-form-large {
        padding: 20px;
        height: 620px;
        width: 100%;
        display: flex;
        overflow: scroll;
        scroll-behavior: smooth;
        list-style: none;
        margin: 0;
        }
        
        .container-form-large form {
            margin-left: auto;
            margin-right: auto;
            justify-content: center;
            align-items: center;
        }
        
        .container-form-large input[type=text], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form-large input[type=email], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form-large input[type=number], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form-large input[type=tel], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form-large input[type=file], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form-large input[type=password], select, textarea {
          width: 100%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .container-form-large input[type=checkbox] {
            display: block;
            margin-bottom: 2px;
            margin-top: 2px;
        }
        
        .container-form-large video {
            width: 55px; 
            height: 45px;
        }
        
        .container-form-large #logo {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        
        .container-form-large #header-codes {
            width: 250px;
        }
        
        .container-form-large #advert-form {
            width: 200px;
        }

        .container-form-large button {
         color: #ffffff;
         text-decoration: none;
         background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
         border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
         margin-bottom: 5px;
         padding: 5px;
        }

        .container-form-large #reset-button {
            margin-left: 5px;
            margin-bottom: 5px;
        }

        .container-form-large button:hover{
         color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .container-form-large a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .container-form-large a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        
        @media only screen and (min-width: 970px) {
            .container-form-large form {
                max-width: 70%;
            }
            
            .container-form-large #register-form {
                max-width: 50%;
            }
            
            .container-form-large #header-codes {
                width: 500px;
            }
            
            .container-form-large #advert-form {
                width: 300px;
            }
        }

        .container-form-page {
          height: 500px;
          width: 100%;
          display: flex;
          overflow: scroll;
          scroll-behavior: smooth;
          list-style: none;
          margin: 0;
      }

      .container-form-page form {
        justify-content: left;
        align-items: left;
      }

      .container-form-page input[type=text], select, textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }

      .container-form-page input[type=email], select, textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }

      .container-form-page input[type=number], select, textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }

      .container-form-page input[type=tel], select, textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }

      .container-form-page input[type=file], select, textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }

      .container-form-page input[type=password], select, textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }

      .container-form-page input[type=checkbox] {
        display: block;
        margin-bottom: 2px;
        margin-top: 2px;
      }

      .container-form-page video {
        width: 55px; 
        height: 45px;
      }

      .container-form-page #logo {
        display: block;
        margin-left: auto;
        margin-right: auto;
      }

      .container-form-page #header-codes {
        width: 250px;
      }

      .container-form-page #advert-form {
        width: 200px;
      }

      .container-form-page button {
        color: #ffffff;
        text-decoration: none;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        margin-bottom: 5px;
        padding: 5px;
      }

      .container-form-page #reset-button {
        margin-left: 5px;
        margin-bottom: 5px;
      }

      .container-form-page button:hover{
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
      }

      .container-form-page a {
        text-decoration: none;
        color: <?php echo $result_siteinfo["primary_color"]; ?>;
      }

      .container-form-page a:hover {
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
      }

      @media only screen and (min-width: 970px) {
        .container-form-page form {
          max-width: 70%;
        }

        .container-form-page #register-form {
          max-width: 50%;
        }

        .container-form-page #header-codes {
          width: 500px;
        }

        .container-form-page #advert-form {
          width: 300px;
        }
      }

    </style>

    <!-- For the library -->
    <style>
        .bg-container .form-library{
            margin-left: auto; 
            margin-right: auto; 
            justify-content: center; 
            align-items: center; 
            text-align: center; 
            border: 1px; 
            width: 70%;
        }

        .form-library button{
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            border-radius: 5px;
            margin: 5px;
            padding: 3px;
        }

        .form-library button:hover{
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .bg-container .latest-library #myUL{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }

        .library{
            position: relative;
            width: 300px;
            justify-content: center;
            align-items: center;
            text-align: center;
            box-shadow: 0 2px 7px <?php echo $result_siteinfo["primary_color"]; ?>;
            border-radius: 4px;
            margin: 20px;
            box-sizing: border-box;
            overflow: hidden;
        }

        .library button{
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            text-align: center;
            border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            border-radius: 5px;
            margin: 5px;
            padding: 5px;
        }

        .library button:hover{
            border-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }

        .library a{
            text-decoration: none;
            margin: 5px;
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        .library iframe{
        height: 150px;
        width: 300px;
        border-radius: 5px;
        }
    </style>
    
    <!--For maintenance page-->
    <style>
        .maintenance_page {
            background-image: url(https://www.inbuiltweb.com/assets/Inbuiltweb_bot_error.webp);
            background-size: 500px;
            background-repeat: no-repeat;
            background-position: center;
            background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
            height: 100vh;
            text-align: center;
        }
        
        .maintenance_page h2 {
            margin-top: 50px;
            color: #e0dddd;
        }
        
        .maintenance_page p {
            margin-top: 20px;
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        
    </style>



    <!-- TEMPORAL CODES -->

    <!-- Font awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="nofollow">

    <!-- Warning for an irreversible action -->
	<script type="text/javascript">
		function checker() {
			var result = confirm ('Are you sure you want to perform this operation?');
			if (result == false) {
				event.preventDefault();
			}
		}
	</script>
	
	<!-- Generating the url -->
	<script>
        function autoInput() {
        // Get the value of input1
        var input1Value = document.getElementById("input1").value;
        // Remove special characters from input1Value, except spaces
        var cleanedValue = input1Value.replace(/[^a-zA-Z0-9\s]/g, "");
        // Set the value of input2 to the cleaned value
        document.getElementById("input2").value = cleanedValue;
        }
    </script>
    
    <!-- Cookie consent -->
    <script>
        // Get the cookie notification element
        const cookieNotification = document.getElementById("cookie-notification");
        
        // Get the accept and reject buttons
        const acceptCookiesBtn = document.getElementById("accept-cookies");
        const rejectCookiesBtn = document.getElementById("reject-cookies");
        
        // Function to set cookies
        function setCookie(name, value, days) {
          const date = new Date();
          date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
          const expires = "expires=" + date.toUTCString();
          document.cookie = name + "=" + value + ";" + expires + ";path=/";
        }
        
        // Function to check if cookie exists
        function checkCookie(name) {
          const cookies = document.cookie.split(";");
          for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith(name + "=")) {
              return true;
            }
          }
          return false;
        }
        
        // Check if user has already accepted cookies
        if (checkCookie("cookies_accepted")) {
          // Do nothing
        } else {
          // Show the cookie notification
          cookieNotification.style.display = "block";
        }
        
        // Event listener for accept cookies button
        acceptCookiesBtn.addEventListener("click", function() {
          setCookie("cookies_accepted", "true", 7);
          cookieNotification.style.display = "none";
        });
        
        // Event listener for reject cookies button
        rejectCookiesBtn.addEventListener("click", function() {
          cookieNotification.style.display = "none";
        });
    </script>
    <style>
        #cookie-notification {
          position: fixed;
          bottom: 0;
          width: 100%;
          text-align: center;
          align-items: center;
          align-content: center;
          background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
          opacity: 0.8;
          padding: 10px;
          border-radius: 10px 10px 0px 0px;
          z-index: 900;
          display: none;
        }
        
        #cookie-notification p {
          color: #ffffff;
          margin: 0;
        }
        
        #cookie-notification a {
          color: <?php echo $result_siteinfo["secondary_color"]; ?>;
          text-decoration: none;
        }
        
        #cookie-notification button {
          background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
          color: #ffffff;
          border-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
          border-radius: 5px;
          padding: 5px;
          margin-left: 5px;
          margin-top: 5px;
          cursor: pointer;
        }
        
        #cookie-notification button:hover {
          background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }
        
        #cookie-notification button:focus {
          outline: none;
          box-shadow: 0 0 0 2px <?php echo $result_siteinfo["primary_color"]; ?>;
        }
    </style>

    <!-- searching tables and lists -->
    <!-- for tables -->
    <script type="text/javascript">
        function searchTable() {
            var input, filter, found, table, tr, td, i, j;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("table-record");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                    }
                }
                if (found) {
                    tr[i].style.display = "";
                    found = false;
                } else {
                    tr[i].style.display = "none";
                }
            }
        }

        function searchTableLarge() {
            var input, filter, found, table, tr, td, i, j;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("table-record-large");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                    }
                }
                if (found) {
                    tr[i].style.display = "";
                    found = false;
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    </script>
    <!-- for lists -->
    <script>
        const inputElement = document.getElementById('myInput');
        const logItems = document.querySelectorAll('.log-item');

        inputElement.addEventListener('input', function () {
            const searchTerm = inputElement.value.toLowerCase();

            logItems.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    </script>

    <!-- Gtranslate -->
    <style>div.skiptranslate,#google_translate_element2{display:none!important;}body{top:0!important;}</style>
    
    <script>function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}if(!window.gt_translate_script){window.gt_translate_script=document.createElement('script');gt_translate_script.src='https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2';document.body.appendChild(gt_translate_script);}</script>
    
    <script>
    function GTranslateGetCurrentLang() {var keyValue = document['cookie'].match('(^|;) ?googtrans=([^;]*)(;|$)');return keyValue ? keyValue[2].split('/')[2] : null;}
    function GTranslateFireEvent(element,event){try{if(document.createEventObject){var evt=document.createEventObject();element.fireEvent('on'+event,evt)}else{var evt=document.createEvent('HTMLEvents');evt.initEvent(event,true,true);element.dispatchEvent(evt)}}catch(e){}}
    function doGTranslate(lang_pair){if(lang_pair.value)lang_pair=lang_pair.value;if(lang_pair=='')return;var lang=lang_pair.split('|')[1];if(GTranslateGetCurrentLang() == null && lang == lang_pair.split('|')[0])return;if(typeof ga=='function'){ga('send', 'event', 'GTranslate', lang, location.hostname+location.pathname+location.search);}var teCombo;var sel=document.getElementsByTagName('select');for(var i=0;i<sel.length;i++)if(sel[i].className.indexOf('goog-te-combo')!=-1){teCombo=sel[i];break;}if(document.getElementById('google_translate_element2')==null||document.getElementById('google_translate_element2').innerHTML.length==0||teCombo.length==0||teCombo.innerHTML.length==0){setTimeout(function(){doGTranslate(lang_pair)},500)}else{teCombo.value=lang;GTranslateFireEvent(teCombo,'change');GTranslateFireEvent(teCombo,'change')}}
    </script>

    <!-- Tooltips -->
    <style type="text/css">
        #tooltip {
        position: relative;
        display: inline-block;
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        #tooltip .tooltiptext {
        visibility: hidden;
        width: 200px;
        background-color: <?php echo $result_siteinfo["primary_color"]; ?>;
        color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0;
        
        /* Position the tooltip */
        position: absolute;
        z-index: 7;
        top: -5px;
        right: 100%;
        }

        #tooltip .tooltiptext a {
            color: #ffffff;
            text-decoration: none;
        }

        #tooltip .tooltiptext a:hover {
            color: <?php echo $result_siteinfo["secondary_color"]; ?>;
        }

        #tooltip:hover .tooltiptext {
        visibility: visible;
        }
        
        @media only screen and (max-width: 970px) {
            #tooltip .tooltiptext {
                left: 100%;
                width: 150px;
            }
        }
    </style>

    <!-- alerts -->
    <style type="text/css">
        .alert-user {
            justify-content: center;
            align-items: center;
            text-align: center;
            background-color: <?php echo $result_siteinfo["secondary_color"]; ?>;
            margin: 20px;
        }

        .alert-user .alert-danger {
            color: #ff0000;
            text-align: center;
        }

        .alert-user .alert-success {
            color: #008000;
            text-align: center;
        }

        .alert-user a {
            text-decoration: none;
            color: <?php echo $result_siteinfo["primary_color"]; ?>;
        }
    </style>
    
    <!-- alert for a successful copied text -->
     <script>
      function copyText(id) {
        // Get the text to be copied
        var text = document.getElementById(id).innerText;

        // Create a temporary textarea element
        var textArea = document.createElement("textarea");

        // Set the textarea value to be the text to be copied
        textArea.value = text;

        // Add the textarea to the DOM
        document.body.appendChild(textArea);

        // Select the textarea
        textArea.select();

        // Copy the text
        document.execCommand("copy");

        // Remove the textarea from the DOM
        document.body.removeChild(textArea);

        // Alert the user that the text has been copied
        alert("Copied to clipboard!");
      }
    </script>